#include "stm32f10x.h"
void TimeFunction(int Temps);                                                                   //creat the time function for the delay time
int decoder_7seg[4] = {0xB0A4F9C0,0xF8829299,0x83889080,0x8E86A1A7};                            // initializing the displayed values 0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F

int i,j,k,value;                                                                                // Variables for iteration and display control
int disp_index, disp_val;                                                                       // Variables to determine the digit to display and its value
int disp[4] = {2,0,0,2};                                                                        // Array representing the year of birth (2002)

int main(void)                                                                                  //Main function setting up GPIO pins for the 7-segment display and controlling the display based on the date of birth.
{
    RCC->APB2ENR |= 0x00000008;                                                                 // Enable clock for GPIOB
    GPIOB->CRL = (GPIOB->CRL & 0x0000FFF0) | 0x33330004;                                        // Configure GPIO CRL  pins for output(P0) and (P4 to P7)
    GPIOB->CRH = 0x33333333;                                                                    // Configure GPIOB CRH  pins for output(P8 to P15)
    GPIOB->BSRR = 0xFFF00000;                                                                   // Reset all segments initially
    while(1)
    {
        i = GPIOB->IDR & 0x00000001;                                                            // Read input push buttom 
        if (i == 0x00000001)                                                                    // Check if button is pressed(the state of the push buttom)
        {
            for (j=0; j<4; j++)                                                                 // Iterate through each digit of the date
            {
                GPIOB->BRR = 0x0000FFF0;                                                        // Reset all segments
                disp_index = disp[j]>>2;                                                        // Determine the index in the decoder array
                disp_val = (disp[j]&0x00000003)<<3;                                             // Calculate the value to display
                value = (((decoder_7seg[disp_index]>>disp_val)&0x000000FF)<<8) & 0x0000FF00;    // determine the desired value to display  
                value |= 1 << (4+j);                                                            // Set the corresponding digit control bit(display the desired value)
                GPIOB->BSRR = value;                                                            // Display the digit
                TimeFunction(1);                                                                // Delay function for display 
                GPIOB->BRR = value;                                                             // Turn off the displayed digit
            }
        }
    }
}

void TimeFunction(int Temps)
{
    int j,k;
    for (j=0;j<Temps;j++)
    {
        for (k=0;k<2882;k++)
        {
        }
				                                                                                        // Delay loop
    }
}